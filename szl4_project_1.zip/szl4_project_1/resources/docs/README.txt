/**
 * README.txt
 * 
 * Az eddig leadott doksik ertekelese...
 */

 --- DOC-NAME ---	--- KAPOTT/MAX ---	--- COMMENT ---

 2_kovetelmenyek	       8/10
 3_analysis_v1		      10/20			      :(
 5_analysis2_beadando     28/30
 SzkeletonTerv_v0.3.docx  20/20