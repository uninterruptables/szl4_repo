package team.uninter.mordorq.gamespace;

public enum Neighbour {
	NORTH,SOUTH,EAST,WEST
}
