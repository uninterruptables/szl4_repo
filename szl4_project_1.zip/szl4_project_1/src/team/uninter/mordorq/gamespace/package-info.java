/**
 * 
 */
/**
 * @author Imre Szekeres
 *
 */
package team.uninter.mordorq.gamespace;