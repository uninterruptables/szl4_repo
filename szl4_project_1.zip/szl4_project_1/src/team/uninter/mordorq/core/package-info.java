/**
 * 
 */
/**
 * @author Imre Szekeres
 *
 */
package team.uninter.mordorq.core;