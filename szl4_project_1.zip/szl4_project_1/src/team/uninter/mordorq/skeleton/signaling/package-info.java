/**
 * 
 */
/**
 * @author redcloud
 *
 */
package team.uninter.mordorq.skeleton.signaling;