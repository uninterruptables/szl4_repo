/**
 * package-info.java
 */
/**
 * 
 * @author redcloud
 * @version "%I%, %G%"
 */
package team.uninter.mordorq.prototype;